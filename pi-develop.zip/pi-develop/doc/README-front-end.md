Front-end building asset
----------------
Tools: [gruntjs](http://gruntjs.com/)

To execute asset build, use:

```
grunt 
```

To execute clear asset build files, use

```
grunt clear
```

To execute 'www/asset' and 'www/public' files to usr, use

```
grunt back
```


-- By @sexnothing
