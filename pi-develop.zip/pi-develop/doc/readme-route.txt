
see usr/locale/README.md