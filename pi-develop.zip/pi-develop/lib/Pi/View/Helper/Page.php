<?php
/**
 * Pi Engine (http://piengine.org)
 *
 * @link            http://code.piengine.org for the Pi Engine source repository
 * @copyright       Copyright (c) Pi Engine http://piengine.org
 * @license         http://piengine.org/license.txt BSD 3-Clause License
 * @package         View
 */

namespace Pi\View\Helper;

use Laminas\View\Helper\AbstractHtmlElement;

/**
 * Helper for building page link
 *
 * Usage
 * ```
 *  // Display original `about-us` link
 *  echo $this->page('about-us', __('About us));
 *
 *  // Display `about-us` link with specified attributes
 *  echo $this->page('about-us', __('About us), array('target' => '_blank'));
 *
 *  // Display `about-us` link with customized hover title
 *  echo $this->page('about-us', __('About us), array('target' => '_blank', 'title' => __('About the team')));
 *
 *  // Display `about-us` link with customized hover title and display blocks assigned to `corporate` type pages
 *  echo $this->page('about-us', __('About us), array('target' => '_blank', 'title' => __('About the team'), 'type' => 'corporate'));
 * ```
 *
 * @author Taiwen Jiang <taiwenjiang@tsinghua.org.cn>
 */
class Page extends AbstractHtmlElement
{
    /**
     * Output page link
     *
     * @param string $name       Page name or slug
     * @param string $title
     * @param array  $attributes Link attributes
     *
     * @return string
     */
    public function __invoke($name, $title, $attributes = [])
    {
        $pattern = '<a href="%s"%s>%s</a>';
        if (!isset($attributes['title'])) {
            $attributes['title'] = $title;
        }
        $type = '';
        if (isset($attributes['type'])) {
            $type = $attributes['type'];
            unset($attributes['type']);
        }
        $attribs = $this->htmlAttribs($attributes);
        try {
            $params = ['name' => $name];
            if ($type) {
                $params['type'] = $type;
            }
            $href = $this->view->url('page', $params);
        } catch (\Exception $e) {
            $href = '#';
        }

        $html = sprintf(
            $pattern,
            $href,
            $attribs,
            $title
        );

        return $html;
    }
}
