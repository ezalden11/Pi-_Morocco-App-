<?php
/**
 * Pi Engine (http://piengine.org)
 *
 * @link            http://code.piengine.org for the Pi Engine source repository
 * @copyright       Copyright (c) Pi Engine http://piengine.org
 * @license         http://piengine.org/license.txt BSD 3-Clause License
 */

namespace Pi\View\Resolver;

use Pi;
use Laminas\View\Renderer\RendererInterface as Renderer;
use Laminas\View\Resolver\ResolverInterface;

/**
 * Component template resolver
 *
 * Component template folders/files skeleton
 *
 *  - Component native templates
 *    `lib/Pi/Captcha/Image/template/`
 *
 *  - Component custom templates
 *    `theme/default/lib/Pi/Captcha/Image/template/`
 *
 * @see    Pi\View\Resolver\ModuleTemplate for module template skeleton
 * @see    Pi\View\Resolver\ThemeTemplate for theme template skeleton
 * @see    Pi\Application\Service\Asset for asset skeleton
 * @author Taiwen Jiang <taiwenjiang@tsinghua.org.cn>
 */
class ComponentTemplate implements ResolverInterface
{
    /**
     * Theme template directory
     *
     * @var string
     */
    protected $templateDirectory = 'template';

    /**
     * Suffix to use: appends this suffix if the template requested
     * does not use it.
     *
     * @var string
     */
    protected $suffix = 'phtml';

    /**
     * Set default file suffix
     *
     * @param string $suffix
     *
     * @return self
     */
    public function setSuffix($suffix)
    {
        $this->suffix = (string)$suffix;

        return $this;
    }

    /**
     * Get file suffix
     *
     * @return string
     */
    public function getSuffix()
    {
        return $this->suffix;
    }

    /**
     * Canonize template
     *
     * @param string $name
     *
     * @return array Pair of component name and template file
     */
    protected function canonizeTemplate($name)
    {
        if (substr($name, -6) == '.' . $this->suffix) {
            $name = substr($name, 0, -6);
        }
        [$component, $template] = explode(':', $name, 2);

        return [$component, $template];
    }

    /**
     * Retrieve the filesystem path to a view script
     *
     * @param string        $name
     * @param null|Renderer $renderer
     *
     * @return string|false
     */
    public function resolve($name, Renderer $renderer = null)
    {
        if (false === strpos($name, ':')) {
            return false;
        }
        $renderer->context('component');
        [$component, $template] = $this->canonizeTemplate($name);
        // Check custom template in theme
        $path = sprintf(
            '%s/%s/%s/%s/%s.%s',
            Pi::path('theme'),
            Pi::config('theme'),
            $component,
            $this->templateDirectory,
            $template,
            $this->suffix
        );
        if (file_exists($path)) {
            return $path;
        }
        // Check local template in module
        $path = sprintf(
            '%s/%s/%s.%s',
            Pi::path($component),
            $this->templateDirectory,
            $template,
            $this->suffix
        );
        if (file_exists($path)) {
            return $path;
        }
        $renderer->context('');

        return false;
    }
}
