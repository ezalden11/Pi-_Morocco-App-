<?php
/**
 * Pi Engine (http://piengine.org)
 *
 * @link            http://code.piengine.org for the Pi Engine source repository
 * @copyright       Copyright (c) Pi Engine http://piengine.org
 * @license         http://piengine.org/license.txt BSD 3-Clause License
 * @package         Form
 */

namespace Pi\Form\Element;

use Laminas\Form\Element\Select;

/**
 *  Cache granularity select element
 *
 * @author Taiwen Jiang <taiwenjiang@tsinghua.org.cn>
 */
class CacheLevel extends Select
{
    /**
     * Get options of value select
     *
     * @return array
     */
    public function getValueOptions()
    {
        if (empty($this->valueOptions)) {
            $this->valueOptions = [
                'whole'  => __('As a whole'),
                'locale' => __('Per language'),
                'role'   => __('Per role'),
                'guest'  => __('Guest only'),
                //'auth'      => __('Authenticated or not'),
                //'user'      => __('By user'),
            ];
        }

        return $this->valueOptions;
    }

    /**
     * {@inheritDoc}
     */
    public function getLabel()
    {
        if (null === $this->label) {
            $this->label = __('Cache granularity');
        }

        return parent::getLabel();
    }
}
