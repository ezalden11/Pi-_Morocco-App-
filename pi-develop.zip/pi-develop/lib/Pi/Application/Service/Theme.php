<?php
/**
 * Pi Engine (http://piengine.org)
 *
 * @link            http://code.piengine.org for the Pi Engine source repository
 * @copyright       Copyright (c) Pi Engine http://piengine.org
 * @license         http://piengine.org/license.txt BSD 3-Clause License
 * @package         Service
 */

namespace Pi\Application\Service;

use Pi;

/**
 * Theme handling service
 *
 * @author Taiwen Jiang <taiwenjiang@tsinghua.org.cn>
 */
class Theme extends AbstractService
{
    /** @var string Default theme name */
    const DEFAULT_THEME = 'default';

    /** @var string Current theme name */
    protected $currentTheme;

    /**
     * Set current active theme
     *
     * @param string $theme
     *
     * @return Theme
     */
    public function setTheme($theme)
    {
        $this->currentTheme = $theme;
        return $this;
    }

    /**
     * Get current active theme
     *
     * @return string
     */
    public function current()
    {
        if (!$this->currentTheme) {
            switch (Pi::engine()->section()) {
                case 'front':
                case 'feed':
                    $this->currentTheme = Pi::config('theme');
                    break;

                case 'admin':
                    $this->currentTheme = Pi::config('theme_admin');
                    break;
            }
            /* $this->currentTheme = ('front' == Pi::engine()->section())
                    ? Pi::config('theme') : Pi::config('theme_admin'); */
            $this->currentTheme = $this->currentTheme ?: 'default';
        }

        return $this->currentTheme;
    }

    /**
     * Load theme configuration from file
     *
     * @param string $theme
     *
     * @return array
     */
    public function loadConfig($theme)
    {
        $configFile = sprintf('%s/config.php', $this->path($theme));
        if (file_exists($configFile)) {
            $config = include $configFile;
        } else {
            $config = [];
        }

        return $config;
    }

    /**
     * Get path to theme location
     *
     * @param string $theme
     *
     * @return string
     */
    public function path($theme = '')
    {
        $theme = $theme ?: $this->current();
        $path  = Pi::path('theme') . '/' . $theme;

        return $path;
    }

    /**
     * Get parent theme
     *
     * @param string $theme
     *
     * @return string
     */
    public function getParent($theme = null)
    {
        $theme  = $theme ?: $this->current();
        $config = $this->loadConfig($theme);
        $parent = !empty($config['parent'])
            ? $config['parent']
            : ($theme == static::DEFAULT_THEME ? '' : static::DEFAULT_THEME);

        return $parent;
    }

    /**
     * Get list of themes
     *
     * @param string $type
     *
     * @return array
     */
    public function getThemes($type = 'front')
    {
        $list   = [];
        $themes = Pi::registry('theme')->read($type);
        foreach ($themes as $name => $theme) {
            $list[$name] = $theme['title'];
        }

        return $list;
    }

    /**
     * Get layout list of a theme
     *
     * @param string $theme
     *
     * @return array
     */
    public function getLayouts($theme = '')
    {
        $list = [
            'layout-front'   => __('Full layout (header/footer and blocks)'),
            'layout-simple'  => __('Simple layout (header/footer)'),
            'layout-style'   => __('Content only (with style)'),
            'layout-content' => __('Raw content (no style)'),
        ];
        if ($theme) {
            Pi::service('i18n')->loadTheme('default', $theme);
            $config = $this->loadConfig($theme);
            if (!empty($config['layout'])) {
                $list += $config['layout'];
            }
        }

        return $list;
    }

    /**
     * @return array|mixed
     */
    public function getThemeVars()
    {
        $themeConfig = $this->loadConfig('');

        // First we convert the array to a json string
        $json = json_encode($themeConfig['vars']);

        // The we convert the json string to a stdClass()
        $vars = json_decode($json);

        return $vars;
    }
}
