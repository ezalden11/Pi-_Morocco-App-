<?php
/**
 * Pi Engine (http://piengine.org)
 *
 * @link            http://code.piengine.org for the Pi Engine source repository
 * @copyright       Copyright (c) Pi Engine http://piengine.org
 * @license         http://piengine.org/license.txt BSD 3-Clause License
 * @package         Registry
 */

namespace Pi\Application\Registry;

use Pi;

/**
 * Module search callback list
 *
 * @author Taiwen Jiang <taiwenjiang@tsinghua.org.cn>
 */
class Search extends AbstractRegistry
{
    /**
     * {@inheritDoc}
     * @param array $options Potential values for type:
     *                       active, inactive, all
     *
     * @return  array   Keys: dirname => callback, active
     */
    protected function loadDynamic($options = [])
    {
        $model = Pi::model('search');

        if (!empty($options['active'])) {
            $where['active'] = 1;
        } elseif (null !== $options['active']) {
            $where['active'] = 0;
        }
        $rowset = $model->select($where);

        $modules = [];
        foreach ($rowset as $row) {
            $modules[$row->module] = $row->callback;
        }

        return $modules;
    }

    /**
     * {@inheritDoc}
     * @param bool $active
     */
    public function read($active = true)
    {
        $options = compact('active');

        return $this->loadData($options);
    }

    /**
     * {@inheritDoc}
     * @param bool $active
     */
    public function create($active = true)
    {
        $this->clear('');
        $this->read($active);

        return true;
    }

    /**
     * {@inheritDoc}
     */
    public function setNamespace($meta = '')
    {
        return parent::setNamespace('');
    }

    /**
     * {@inheritDoc}
     */
    public function flush()
    {
        return $this->clear('');
    }
}
