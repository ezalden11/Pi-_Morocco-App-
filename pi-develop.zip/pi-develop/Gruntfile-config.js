module.exports = {
  /* 
   * Which modules will be handler by grunt
   * Array list or string 'all'
   */
   modules: 'all',
  /* 
   * Which themes will be handler by grunt
   * Array list or string 'all'
   */
  themes: 'all',
  exclude: '!**/sym/**'
};